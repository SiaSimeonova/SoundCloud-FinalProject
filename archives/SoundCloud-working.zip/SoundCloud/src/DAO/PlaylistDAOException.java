package DAO;

public class PlaylistDAOException extends Exception {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PlaylistDAOException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PlaylistDAOException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public PlaylistDAOException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PlaylistDAOException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PlaylistDAOException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
