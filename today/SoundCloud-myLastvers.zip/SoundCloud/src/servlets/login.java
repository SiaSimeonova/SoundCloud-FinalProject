package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import DAO.UserDAO;
import DAO.UserDAOException;
import POJO.User;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		String user = request.getParameter("username");
		String pass = request.getParameter("password");
		boolean isThereSuchUser = false;
		try {
			isThereSuchUser = new UserDAO().isThereSuchUser(user, pass);
		} catch (UserDAOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			response.sendRedirect("./error.jsp");

		}
		if (isThereSuchUser) {

			HttpSession session = request.getSession();
			User userToBeAdded = null;
			try {

				userToBeAdded = new UserDAO().getUser(user);
			} catch (UserDAOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				response.sendRedirect("./error.jsp");

			}
			session.setAttribute("user", userToBeAdded);
			response.sendRedirect("./header.jsp");
		} else {
			response.sendRedirect("./signIn.jsp");
		}
	}

}
